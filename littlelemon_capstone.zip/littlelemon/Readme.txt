LITTLE LEMON - Back-end capstone (Django + Django REST Framework + MySQL)

SETUP
1. In MySQL:  CREATE DATABASE littlelemon;
2. Set your MySQL user/password in littlelemon/settings.py (DATABASES) or via env vars:
   LL_DB_USER, LL_DB_PASSWORD, LL_DB_HOST, LL_DB_PORT, LL_DB_NAME
3. Run:
     pipenv shell
     pipenv install
     python manage.py makemigrations
     python manage.py migrate
     python manage.py createsuperuser   (optional, for /admin/)
     python manage.py runserver
4. Unit tests:  python manage.py test      (needs permission to create a test DB in MySQL)

HTML PAGES (served by Django)
  http://127.0.0.1:8000/                 Home
  http://127.0.0.1:8000/about/           About
  http://127.0.0.1:8000/menu/            Menu (from database)
  http://127.0.0.1:8000/book/            Booking form (fetch API, date picker, booked slots greyed out)
  http://127.0.0.1:8000/reservations/    All bookings as JSON
  http://127.0.0.1:8000/bookings?date=YYYY-MM-DD   Bookings for one date (JSON)

API PATHS TO TEST (Insomnia)
  User registration
    POST   http://127.0.0.1:8000/auth/users/                 {"username": "...", "password": "..."}
  Authentication (token)
    POST   http://127.0.0.1:8000/auth/token/login/           {"username": "...", "password": "..."}
                                                              -> {"auth_token": "<token>"}
    GET    http://127.0.0.1:8000/auth/users/me/              header  Authorization: Token <token>
    POST   http://127.0.0.1:8000/auth/token/logout/          header  Authorization: Token <token>

  Menu API  (GET is public; POST/PUT/PATCH/DELETE need the token header)
    GET    http://127.0.0.1:8000/api/menu/
    POST   http://127.0.0.1:8000/api/menu/                   {"title":"Greek Salad","price":"12.50","inventory":20,"description":"..."}
    GET    http://127.0.0.1:8000/api/menu/1/
    PUT    http://127.0.0.1:8000/api/menu/1/
    PATCH  http://127.0.0.1:8000/api/menu/1/
    DELETE http://127.0.0.1:8000/api/menu/1/

  Table booking API  (all methods need header  Authorization: Token <token>)
    GET    http://127.0.0.1:8000/api/bookings/
    POST   http://127.0.0.1:8000/api/bookings/               {"first_name":"Sam","reservation_date":"2026-12-13","reservation_slot":14,"no_of_guests":3}
    GET    http://127.0.0.1:8000/api/bookings/1/
    PUT    http://127.0.0.1:8000/api/bookings/1/
    PATCH  http://127.0.0.1:8000/api/bookings/1/
    DELETE http://127.0.0.1:8000/api/bookings/1/
  (A duplicate date + slot returns HTTP 400.)
