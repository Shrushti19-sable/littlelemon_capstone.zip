from django.contrib.auth.models import User
from django.test import TestCase
from rest_framework.test import APIClient

from .models import Booking, Menu


class ModelTests(TestCase):
    def test_menu_str(self):
        item = Menu.objects.create(title="IceCream", price=80, inventory=100)
        self.assertEqual(str(item), "IceCream : 80")

    def test_booking_str(self):
        b = Booking.objects.create(first_name="Ana", reservation_date="2026-11-01", reservation_slot=12)
        self.assertIn("Ana", str(b))


class MenuApiTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.item = Menu.objects.create(title="Greek Salad", price="12.50", inventory=20)

    def test_menu_list_is_public(self):
        r = self.client.get("/api/menu/")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()[0]["title"], "Greek Salad")

    def test_single_item_is_public(self):
        r = self.client.get(f"/api/menu/{self.item.id}/")
        self.assertEqual(r.status_code, 200)

    def test_create_requires_auth(self):
        r = self.client.post("/api/menu/", {"title": "Pasta", "price": "9.00", "inventory": 5}, format="json")
        self.assertEqual(r.status_code, 401)

    def test_authenticated_crud(self):
        user = User.objects.create_user("chef", password="pw12345!x")
        self.client.force_authenticate(user)
        r = self.client.post("/api/menu/", {"title": "Pasta", "price": "9.00", "inventory": 5}, format="json")
        self.assertEqual(r.status_code, 201)
        pk = r.json()["id"]
        r = self.client.put(f"/api/menu/{pk}/", {"title": "Pasta", "price": "10.00", "inventory": 4}, format="json")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(Menu.objects.get(pk=pk).inventory, 4)
        r = self.client.delete(f"/api/menu/{pk}/")
        self.assertEqual(r.status_code, 204)


class BookingApiTests(TestCase):
    payload = {"first_name": "Sam", "reservation_date": "2026-12-13", "reservation_slot": 14, "no_of_guests": 3}

    def setUp(self):
        self.client = APIClient()
        self.user = User.objects.create_user("sam", password="pw12345!x")

    def test_requires_auth(self):
        self.assertEqual(self.client.get("/api/bookings/").status_code, 401)

    def test_create_list_and_duplicate(self):
        self.client.force_authenticate(self.user)
        self.assertEqual(self.client.post("/api/bookings/", self.payload, format="json").status_code, 201)
        self.assertEqual(len(self.client.get("/api/bookings/").json()), 1)
        dup = self.client.post("/api/bookings/", self.payload, format="json")
        self.assertEqual(dup.status_code, 400)

    def test_update_and_delete(self):
        self.client.force_authenticate(self.user)
        pk = self.client.post("/api/bookings/", self.payload, format="json").json()["id"]
        r = self.client.patch(f"/api/bookings/{pk}/", {"no_of_guests": 6}, format="json")
        self.assertEqual(r.json()["no_of_guests"], 6)
        self.assertEqual(self.client.delete(f"/api/bookings/{pk}/").status_code, 204)


class AuthTests(TestCase):
    def test_register_login_and_use_token(self):
        c = APIClient()
        r = c.post("/auth/users/", {"username": "newuser", "password": "Str0ng-pass-99"}, format="json")
        self.assertEqual(r.status_code, 201)
        r = c.post("/auth/token/login/", {"username": "newuser", "password": "Str0ng-pass-99"}, format="json")
        self.assertEqual(r.status_code, 200)
        token = r.json()["auth_token"]
        c.credentials(HTTP_AUTHORIZATION=f"Token {token}")
        self.assertEqual(c.get("/api/bookings/").status_code, 200)
        self.assertEqual(c.get("/auth/users/me/").json()["username"], "newuser")


class PageTests(TestCase):
    def test_static_html_pages(self):
        for url in ["/", "/about/", "/menu/", "/book/", "/reservations/"]:
            self.assertEqual(self.client.get(url).status_code, 200, url)

    def test_bookings_for_date_json(self):
        Booking.objects.create(first_name="Lee", reservation_date="2026-12-13", reservation_slot=10)
        r = self.client.get("/bookings?date=2026-12-13")
        self.assertEqual(len(r.json()), 1)
        self.assertEqual(self.client.get("/bookings?date=2026-12-14").json(), [])
