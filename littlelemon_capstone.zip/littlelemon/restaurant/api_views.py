from rest_framework import generics, viewsets
from rest_framework.permissions import IsAuthenticated

from .models import Booking, Menu
from .serializers import BookingSerializer, MenuSerializer


class MenuItemsView(generics.ListCreateAPIView):
    """GET (public) list menu items; POST (authenticated) add one."""
    queryset = Menu.objects.all().order_by("id")
    serializer_class = MenuSerializer


class SingleMenuItemView(generics.RetrieveUpdateDestroyAPIView):
    """GET (public); PUT / PATCH / DELETE (authenticated)."""
    queryset = Menu.objects.all()
    serializer_class = MenuSerializer


class BookingViewSet(viewsets.ModelViewSet):
    """Full CRUD on table bookings. Authentication required."""
    queryset = Booking.objects.all().order_by("reservation_date", "reservation_slot")
    serializer_class = BookingSerializer
    permission_classes = [IsAuthenticated]
