from django.db import models


class Booking(models.Model):
    first_name = models.CharField(max_length=200)
    reservation_date = models.DateField()
    reservation_slot = models.SmallIntegerField(default=10)
    no_of_guests = models.PositiveSmallIntegerField(default=1)

    class Meta:
        # One booking per date + time slot
        unique_together = ("reservation_date", "reservation_slot")

    def __str__(self):
        return f"{self.first_name} - {self.reservation_date} @ {self.reservation_slot}:00"


class Menu(models.Model):
    title = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=6, decimal_places=2)
    inventory = models.PositiveIntegerField(default=0)
    description = models.TextField(max_length=1000, blank=True, default="")

    def __str__(self):
        return f"{self.title} : {self.price}"
