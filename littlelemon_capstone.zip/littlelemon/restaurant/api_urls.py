from django.urls import include, path
from rest_framework.routers import DefaultRouter

from . import api_views

router = DefaultRouter()
router.register("bookings", api_views.BookingViewSet, basename="booking")

urlpatterns = [
    path("menu/", api_views.MenuItemsView.as_view(), name="api-menu"),
    path("menu/<int:pk>/", api_views.SingleMenuItemView.as_view(), name="api-menu-item"),
    path("", include(router.urls)),
]
