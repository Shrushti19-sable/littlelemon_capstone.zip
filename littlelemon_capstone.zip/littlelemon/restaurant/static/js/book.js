// Slots open from 10:00 to 20:00
const SLOTS = [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20];

const dateInput = document.getElementById("reservation_date");
const slotSelect = document.getElementById("reservation_slot");
const nameInput = document.getElementById("first_name");
const form = document.getElementById("booking-form");
const bookingsDiv = document.getElementById("bookings");
const selectedDateSpan = document.getElementById("selected-date");
const messageP = document.getElementById("message");

function formatSlot(h) {
  const suffix = h < 12 ? "AM" : "PM";
  const hour12 = h % 12 === 0 ? 12 : h % 12;
  return `${hour12}:00 ${suffix}`;
}

function todayLocal() {
  const d = new Date();
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 10);
}

function setMessage(text, isError) {
  messageP.textContent = text;
  messageP.className = isError ? "error" : "success";
}

// Fetch bookings for the chosen date, refresh the list + disable booked slots
function getBookings() {
  const date = dateInput.value;
  selectedDateSpan.textContent = date;

  fetch(`/bookings?date=${encodeURIComponent(date)}`)
    .then((response) => response.json())
    .then((data) => {
      const booked = Array.isArray(data) ? data.map((b) => b.reservation_slot) : [];

      // Rebuild slot options; booked ones are disabled (greyed out)
      const previous = slotSelect.value;
      slotSelect.innerHTML = "";
      SLOTS.forEach((h) => {
        const opt = document.createElement("option");
        opt.value = h;
        const isBooked = booked.includes(h);
        opt.textContent = isBooked ? `${formatSlot(h)} (booked)` : formatSlot(h);
        opt.disabled = isBooked;
        if (isBooked) opt.style.color = "#999";
        slotSelect.appendChild(opt);
      });
      const firstFree = SLOTS.find((h) => !booked.includes(h));
      if (previous && !booked.includes(Number(previous)) && SLOTS.includes(Number(previous))) {
        slotSelect.value = previous;
      } else if (firstFree !== undefined) {
        slotSelect.value = firstFree;
      }

      // Rebuild the bookings list
      bookingsDiv.innerHTML = "";
      if (!Array.isArray(data) || data.length === 0) {
        bookingsDiv.innerHTML = "<p>No Booking</p>";
        return;
      }
      const ul = document.createElement("ul");
      data.forEach((b) => {
        const li = document.createElement("li");
        li.textContent = `${formatSlot(b.reservation_slot)} — ${b.first_name}`;
        ul.appendChild(li);
      });
      bookingsDiv.appendChild(ul);
    })
    .catch(() => {
      bookingsDiv.innerHTML = "<p>Could not load bookings.</p>";
    });
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const payload = {
    first_name: nameInput.value,
    reservation_date: dateInput.value,
    reservation_slot: slotSelect.value,
  };

  fetch("/bookings", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  })
    .then((response) =>
      response.json().then((body) => ({ ok: response.ok, body }))
    )
    .then(({ ok, body }) => {
      if (ok) {
        setMessage("Reservation confirmed!", false);
        nameInput.value = "";
      } else {
        setMessage(body.error || "Could not make reservation.", true);
      }
      getBookings();
    })
    .catch(() => setMessage("Network error. Please try again.", true));
});

// Changing the date refreshes the booking data
dateInput.addEventListener("change", () => {
  setMessage("", false);
  getBookings();
});

// Current date selected by default
dateInput.value = todayLocal();
getBookings();
