import json
from datetime import date, datetime

from django.core import serializers
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

from .models import Booking, Menu


def home(request):
    return render(request, "index.html")


def about(request):
    return render(request, "about.html")


def menu(request):
    menu_data = Menu.objects.all().order_by("title")
    return render(request, "menu.html", {"menu": menu_data})


def book(request):
    return render(request, "book.html")


def reservations(request):
    """Shows ALL bookings as JSON data."""
    bookings = list(
        Booking.objects.all()
        .order_by("reservation_date", "reservation_slot")
        .values("id", "first_name", "reservation_date", "reservation_slot")
    )
    bookings_json = json.dumps(bookings, default=str, indent=2)
    return render(request, "bookings.html", {"bookings": bookings_json})


@csrf_exempt
def bookings(request):
    """
    GET  /bookings?date=YYYY-MM-DD  -> bookings for that date (JSON list)
    POST /bookings                  -> create a booking (JSON body)
    """
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            res_date = datetime.strptime(data["reservation_date"], "%Y-%m-%d").date()
            slot = int(data["reservation_slot"])
            first_name = str(data["first_name"]).strip()
            guests = int(data.get("no_of_guests", 1))
        except (ValueError, KeyError, TypeError):
            return JsonResponse({"error": "Invalid data"}, status=400)

        if not first_name:
            return JsonResponse({"error": "First name is required"}, status=400)

        already_booked = Booking.objects.filter(
            reservation_date=res_date, reservation_slot=slot
        ).exists()
        if already_booked:
            return JsonResponse(
                {"error": "That slot is already booked"}, status=409
            )

        Booking.objects.create(
            first_name=first_name,
            reservation_date=res_date,
            reservation_slot=slot,
            no_of_guests=guests,
        )
        return JsonResponse({"success": True}, status=201)

    # GET
    date_str = request.GET.get("date", date.today().isoformat())
    try:
        res_date = datetime.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        return JsonResponse({"error": "Invalid date"}, status=400)

    qs = Booking.objects.filter(reservation_date=res_date).order_by("reservation_slot")
    data = serializers.serialize("json", qs)
    # Flatten to a simple list of field dicts
    items = [dict(id=o["pk"], **o["fields"]) for o in json.loads(data)]
    return HttpResponse(json.dumps(items), content_type="application/json")
