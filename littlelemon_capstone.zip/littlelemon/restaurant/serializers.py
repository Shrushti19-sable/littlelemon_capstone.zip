from rest_framework import serializers

from .models import Booking, Menu


class MenuSerializer(serializers.ModelSerializer):
    class Meta:
        model = Menu
        fields = ["id", "title", "price", "inventory", "description"]


class BookingSerializer(serializers.ModelSerializer):
    # unique_together on the model gives a built-in "already booked" validator
    class Meta:
        model = Booking
        fields = ["id", "first_name", "reservation_date", "reservation_slot", "no_of_guests"]
