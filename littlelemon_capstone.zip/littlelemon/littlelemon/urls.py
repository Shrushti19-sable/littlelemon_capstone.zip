from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/", include("restaurant.api_urls")),
    path("auth/", include("djoser.urls")),              # user registration: POST /auth/users/
    path("auth/", include("djoser.urls.authtoken")),    # token login: POST /auth/token/login/
    path("", include("restaurant.urls")),
]
